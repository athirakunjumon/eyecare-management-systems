export class student{
    id:Number;
    name:String;
    password:String;
constructor(){

    this.name='';
    this.password='';
    
}
}