<?php
$conn=mysqli_connect("localhost","root","","db_country");
//mysql_select_db($conn,"db_program");

?>