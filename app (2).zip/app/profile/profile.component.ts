import { Component, OnInit } from '@angular/core';
import {student} from '../student';
import{NgForm} from '@angular/forms';
import{ ServiceService } from '../service.service';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  student=new student();
  isregistered=false;


  constructor(private service:ServiceService) { }

  ngOnInit() {
  }
    registration(f: NgForm)
    {
      this.service.store(this.student).subscribe(
        data=>{
          this.isregistered=true;
          console.log("registered successfully");
          f.reset();
        },
        (err)=>{ 
        this.isregistered=false;
        });
    }
  }


